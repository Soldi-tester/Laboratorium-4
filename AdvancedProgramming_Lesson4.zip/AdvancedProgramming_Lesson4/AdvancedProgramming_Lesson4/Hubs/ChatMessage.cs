﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace AdvancedProgramming_Lesson4.Hubs
{
    public class ChatMessage
    {
        public int Id { get; set; }
        [Display(Name = "User")]
        public string UserName { get; set; }
        public string Message { get; set; }
        public bool Authorizated { get; set; }
    }
}